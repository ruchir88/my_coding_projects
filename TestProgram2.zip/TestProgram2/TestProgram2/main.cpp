//
//  main.cpp
//  TestProgram2
//
//  Created by Ruchir Choudhary on 3/24/13.
//  Copyright (c) 2013 Ruchir Choudhary. All rights reserved.
//

#include <iostream>
using namespace std;

class node {
public:
    int data;
    node *next;
};

int main(int argc, const char * argv[])
{
    node *head = new node;
    node *temp = new node;
    node *n = new node;
    
    n->data = 10;
    temp = n;
    head = n;
      
//    temp->data = 20;
//    head->next = temp;
//    temp->next = NULL;
    
    for (int i=0; i < 10; i++) {
        node *n = new node;
        n->data = 2*i;
        temp->next = n;
        temp = temp->next;
    }

    
    while (head != NULL) {
        cout<<"hello "<<head->data<<endl;
        head = head->next;
    }
    
    return 0;
}

